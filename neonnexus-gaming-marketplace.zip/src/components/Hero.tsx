import { motion } from 'motion/react';
import { Gamepad2, ArrowRight, Zap } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 px-4 overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-neon-cyan/20 blur-[120px] rounded-full" />
      <div className="absolute top-1/2 -right-20 w-96 h-96 bg-neon-magenta/20 blur-[120px] rounded-full" />

      <div className="max-w-7xl mx-auto relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full border border-white/10 bg-white/5 mb-8">
            <Zap size={16} className="text-neon-lime" />
            <span className="text-sm font-bold tracking-wider text-white/70">NEXT GEN GAMING ASSETS</span>
          </div>

          <h1 className="text-6xl md:text-8xl font-black tracking-tight leading-[0.9] mb-6">
            EVOLVE YOUR <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan via-white to-neon-magenta animate-pulse">
              GAMEPLAY
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-lg md:text-xl text-white/60 mb-10 leading-relaxed">
            The premium marketplace for digital assets, high-performance skins, and custom mods. 
            Level up your virtual identity with Neon Nexus.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <motion.button
              whileHover={{ scale: 1.05, x: 5 }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto flex items-center justify-center space-x-3 bg-neon-cyan text-black px-10 py-5 rounded-sm font-black italic shadow-neon-cyan hover:brightness-110 transition-all"
            >
              <span>EXPLORE ARMORY</span>
              <ArrowRight size={20} />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto flex items-center justify-center space-x-3 bg-white/5 border border-white/20 text-white px-10 py-5 rounded-sm font-black italic hover:bg-white/10 transition-all"
            >
              <Gamepad2 size={20} />
              <span>SELL ASSETS</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-24 border-t border-white/10 pt-10"
        >
          {[
            { label: 'Active Gamers', value: '1.2M+' },
            { label: 'Total Downloads', value: '50M+' },
            { label: 'Verified Sellers', value: '8.5K' },
            { label: 'Community Rating', value: '4.9/5' },
          ].map((stat, i) => (
            <div key={i} className="text-center md:text-left">
              <div className="text-3xl font-black text-white mb-1">{stat.value}</div>
              <div className="text-xs uppercase tracking-widest text-white/40 font-bold">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
