import React from 'react';
import { motion } from 'motion/react';
import { ShoppingCart, Star, Download, ShieldCheck } from 'lucide-react';
import { Product } from '../types';

interface Props {
  product: Product;
  onAddToCart: () => void;
}

const ProductCard: React.FC<Props> = ({ product, onAddToCart }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -10 }}
      className="group relative bg-dark-card border border-white/5 rounded-2xl overflow-hidden hover:border-neon-cyan/50 transition-all duration-500"
    >
      <div className="relative h-64 overflow-hidden">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-dark-card via-transparent to-transparent opacity-60" />
        <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
          <span className="text-[10px] font-black uppercase tracking-widest text-neon-cyan">{product.category}</span>
        </div>
        <div className="absolute top-4 right-4 bg-neon-magenta text-white px-3 py-1 rounded-full text-xs font-black shadow-neon-magenta">
          ${product.price}
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold tracking-tight text-white group-hover:text-neon-cyan transition-colors">
            {product.name}
          </h3>
          <div className="flex items-center space-x-1 text-neon-lime">
            <Star size={14} fill="currentColor" />
            <span className="text-xs font-bold">{product.rating}</span>
          </div>
        </div>

        <p className="text-white/50 text-sm mb-6 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 text-white/40">
            <div className="flex items-center space-x-1">
              <Download size={14} />
              <span className="text-xs">1.2k</span>
            </div>
            <div className="flex items-center space-x-1">
              <ShieldCheck size={14} />
              <span className="text-xs text-neon-lime">Verified</span>
            </div>
          </div>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onAddToCart}
            className="p-3 bg-white/5 rounded-full border border-white/10 text-white hover:bg-neon-cyan hover:text-black hover:border-neon-cyan transition-all"
          >
            <ShoppingCart size={18} />
          </motion.button>
        </div>
      </div>

      {/* Hover Light Effect */}
      <div className="absolute -inset-px bg-gradient-to-r from-neon-cyan to-neon-magenta opacity-0 group-hover:opacity-10 blur-xl transition-opacity pointer-events-none" />
    </motion.div>
  );
};

export default ProductCard;
