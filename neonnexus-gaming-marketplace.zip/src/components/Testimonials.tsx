import { motion } from 'motion/react';
import { Quote, Star } from 'lucide-react';
import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: '1',
    userName: 'Xander Blaze',
    userAvatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=150&auto=format&fit=crop',
    text: "The quality of these shaders is insane! My streams have never looked better. Highly recommend the Neon pack.",
    rating: 5,
    game: 'Cyberpunk 2077'
  },
  {
    id: '2',
    userName: 'CyberKitten',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop',
    text: "Found the perfect UI kit for my indie game project. The community here is so supportive and the assets are top-tier.",
    rating: 5,
    game: 'Development'
  },
  {
    id: '3',
    userName: 'GhostProtocol',
    userAvatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=150&auto=format&fit=crop',
    text: "Unlimited downloads with the Elite plan is a game changer. I've refreshed my entire library in a week.",
    rating: 4,
    game: 'Call of Duty'
  }
];

export default function Testimonials() {
  return (
    <section className="py-32 px-4 relative bg-dark-bg/50 overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-6xl font-black italic tracking-tighter mb-4 uppercase">
              HEAR FROM THE <br />
              <span className="neon-text-cyan">VANGUARD</span>
            </h2>
            <p className="text-white/50 text-lg">
              Join thousands of elite gamers and creators who are already dominating their virtual worlds.
            </p>
          </div>
          <div className="flex items-center space-x-2 bg-white/5 px-6 py-4 rounded-2xl border border-white/10">
            <span className="text-4xl font-black italic neon-text-lime">4.9</span>
            <div className="flex flex-col">
              <div className="flex text-neon-lime">
                {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Average Rating</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="bg-dark-card border border-white/5 p-8 rounded-3xl relative"
            >
              <Quote className="absolute top-6 right-8 text-white/5" size={60} />
              <div className="flex items-center space-x-4 mb-6">
                <img src={t.userAvatar} alt={t.userName} className="w-12 h-12 rounded-full border border-neon-cyan/30" />
                <div>
                  <h4 className="font-bold text-white">{t.userName}</h4>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-neon-cyan">{t.game}</p>
                </div>
              </div>
              <p className="text-white/70 italic leading-relaxed mb-6 font-medium">"{t.text}"</p>
              <div className="flex text-neon-lime">
                {[...Array(t.rating)].map((_, idx) => <Star key={idx} size={14} fill="currentColor" />)}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
