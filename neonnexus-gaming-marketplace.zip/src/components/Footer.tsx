import { motion } from 'motion/react';
import { Twitter, Github, MessageSquare, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-dark-bg border-t border-white/5 pt-20 pb-10 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-neon-cyan flex items-center justify-center rounded-lg shadow-neon-cyan">
                <span className="font-bold text-black text-lg">N</span>
              </div>
              <span className="text-xl font-black tracking-tighter neon-text-cyan">NEON NEXUS</span>
            </div>
            <p className="text-white/40 max-w-sm mb-8 leading-relaxed">
              The premier destination for elite gaming assets. 
              Built by gamers, for gamers. Join the revolution.
            </p>
            <div className="flex space-x-4">
              {[Twitter, Github, MessageSquare, Mail].map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ y: -5, color: '#00f3ff' }}
                  className="text-white/40 transition-colors"
                >
                  <Icon size={20} />
                </motion.a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs text-white mb-6">Marketplace</h4>
            <ul className="space-y-4 text-sm text-white/40">
              <li><a href="#" className="hover:text-neon-cyan transition-colors">All Assets</a></li>
              <li><a href="#" className="hover:text-neon-cyan transition-colors">3D Models</a></li>
              <li><a href="#" className="hover:text-neon-cyan transition-colors">UI Kits</a></li>
              <li><a href="#" className="hover:text-neon-cyan transition-colors">Shaders</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs text-white mb-6">Company</h4>
            <ul className="space-y-4 text-sm text-white/40">
              <li><a href="#" className="hover:text-neon-cyan transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-neon-cyan transition-colors">Contact</a></li>
              <li><a href="#" className="hover:text-neon-cyan transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-neon-cyan transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[10px] uppercase font-bold tracking-widest text-white/20">
            © 2026 NEON NEXUS INTERACTIVE. ALL RIGHTS RESERVED.
          </p>
          <div className="flex items-center space-x-6 text-[10px] uppercase font-bold tracking-widest text-white/20">
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-neon-lime animate-pulse" />
              <span>Network status: operational</span>
            </span>
            <a href="#" className="hover:text-white transition-colors underline decoration-neon-cyan/20 underline-offset-4">Legal</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
