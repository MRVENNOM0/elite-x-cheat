import { motion } from 'motion/react';
import { Package, Zap, Trophy, Shield } from 'lucide-react';

const plans = [
  {
    name: 'Gamer',
    price: '9',
    description: 'Perfect for casual players looking for a boost.',
    features: ['5 Monthly Downloads', 'Standard Assets', 'Community Discord', 'Weekly Drops'],
    icon: <Zap className="text-neon-cyan text-4xl mb-4" />,
    color: 'neon-cyan',
    accent: 'border-neon-cyan shadow-neon-cyan'
  },
  {
    name: 'Elite',
    price: '29',
    description: 'Our most popular plan for competitive gamers.',
    features: ['Unlimited Downloads', 'Premium Assets', 'Early Access', 'Exclusive Events', 'Pro Dashboard'],
    icon: <Trophy className="text-neon-magenta text-4xl mb-4" />,
    color: 'neon-magenta',
    accent: 'border-neon-magenta shadow-neon-magenta scale-105 z-10',
    popular: true
  },
  {
    name: 'Mythic',
    price: '99',
    description: 'For content creators and pro teams.',
    features: ['Custom Asset Branding', '24/7 Priority Support', 'Beta Testing Access', 'Rev-Share Program', 'Creator Tools'],
    icon: <Shield className="text-neon-lime text-4xl mb-4" />,
    color: 'neon-lime',
    accent: 'border-neon-lime shadow-neon-lime'
  }
];

export default function PricingTables() {
  return (
    <section className="py-32 px-4 bg-dark-bg relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-6xl font-black italic tracking-tighter mb-4 uppercase">
            CHOOSE YOUR <span className="neon-text-magenta">TIER</span>
          </h2>
          <p className="text-white/50 max-w-xl mx-auto">
            Unlock the full potential of Neon Nexus with our subscription tiers. 
            Cancel anytime, no strings attached.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-4 lg:gap-8 items-center">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`relative p-8 rounded-3xl bg-dark-card border border-white/10 flex flex-col ${plan.accent}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-neon-magenta text-xs font-black text-white px-4 py-1 rounded-full uppercase tracking-widest shadow-neon-magenta">
                  Most Popular
                </div>
              )}
              
              <div className="flex flex-col items-center text-center">
                {plan.icon}
                <h3 className="text-2xl font-black mb-2 uppercase">{plan.name}</h3>
                <div className="flex items-baseline mb-6">
                  <span className="text-4xl font-black italic">$</span>
                  <span className="text-6xl font-black italic">{plan.price}</span>
                  <span className="text-white/40 ml-2 font-bold uppercase text-xs">/ Month</span>
                </div>
                <p className="text-sm text-white/40 mb-8">{plan.description}</p>
              </div>

              <div className="space-y-4 mb-10 flex-grow">
                {plan.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center space-x-3">
                    <Package size={16} className={`text-${plan.color}`} />
                    <span className="text-sm font-medium text-white/70">{feature}</span>
                  </div>
                ))}
              </div>

              <button className={`w-full py-4 rounded-xl font-black italic transition-all ${
                plan.popular 
                ? 'bg-neon-magenta text-white shadow-neon-magenta hover:brightness-110' 
                : 'bg-white/5 text-white border border-white/20 hover:bg-white/10'
              }`}>
                JOIN THE NEXUS
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
