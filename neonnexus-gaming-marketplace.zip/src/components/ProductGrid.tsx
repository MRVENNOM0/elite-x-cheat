import { useState } from 'react';
import { motion } from 'motion/react';
import ProductCard from './ProductCard';
import CheckoutModal from './CheckoutModal';
import { Product } from '../types';
import { Search, Filter } from 'lucide-react';

const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Cyber Armor Pro',
    description: 'Fully custom model with reactive LED patterns and high-performance physics modules.',
    price: 45.99,
    category: 'Character Skins',
    imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop',
    sellerId: 's1',
    rating: 4.9
  },
  {
    id: '2',
    name: 'Retrowave Environment Task',
    description: 'Complete AAA environment pack featuring 80s aesthetics and procedural lighting.',
    price: 120.00,
    category: 'Environments',
    imageUrl: 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?q=80&w=800&auto=format&fit=crop',
    sellerId: 's2',
    rating: 4.8
  },
  {
    id: '3',
    name: 'Fusion UI Kit',
    description: 'Clean, futuristic HUD elements with over 500+ animated vector icons and components.',
    price: 19.99,
    category: 'UI/UX',
    imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop',
    sellerId: 's3',
    rating: 5.0
  },
  {
    id: '4',
    name: 'Shadow Katana',
    description: 'Ultra-detail 4K melee weapon with custom particle effects and slash animations.',
    price: 29.99,
    category: 'Weapons',
    imageUrl: 'https://images.unsplash.com/photo-1533512930330-4ac257c86793?q=80&w=800&auto=format&fit=crop',
    sellerId: 's4',
    rating: 4.7
  },
  {
    id: '5',
    name: 'Neon Racer V2',
    description: 'Modified sports car with high-velocity exhaust and customizable light trails.',
    price: 55.00,
    category: 'Vehicles',
    imageUrl: 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?q=80&w=800&auto=format&fit=crop',
    sellerId: 's5',
    rating: 4.9
  },
  {
    id: '6',
    name: 'Apex Shader Suite',
    description: 'Production-ready shaders for water, glass, and atmospheric fog effects.',
    price: 75.00,
    category: 'Shaders',
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=800&auto=format&fit=crop',
    sellerId: 's6',
    rating: 4.6
  }
];

export default function ProductGrid() {
  const [filter, setFilter] = useState('All');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const categories = ['All', 'Character Skins', 'Environments', 'UI/UX', 'Weapons', 'Vehicles', 'Shaders'];

  const filtered = filter === 'All' ? mockProducts : mockProducts.filter(p => p.category === filter);

  return (
    <section className="py-24 px-4 max-w-7xl mx-auto">
      <CheckoutModal 
        product={selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
      />
      
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-6">
        <div className="relative flex-grow max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={20} />
          <input 
            type="text" 
            placeholder="Search Armory..." 
            className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-neon-cyan transition-colors"
          />
        </div>

        <div className="flex overflow-x-auto pb-2 md:pb-0 scrollbar-hide items-center space-x-2">
          <Filter size={18} className="text-white/40 mr-2 flex-shrink-0" />
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                filter === cat 
                ? 'bg-neon-cyan text-black shadow-neon-cyan' 
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map(product => (
          <ProductCard 
            key={product.id} 
            product={product} 
            onAddToCart={() => setSelectedProduct(product)}
          />
        ))}
      </div>

      <div className="mt-16 text-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-transparent border-b-2 border-neon-cyan text-neon-cyan px-8 py-3 font-black italic tracking-widest hover:bg-neon-cyan hover:text-black transition-all"
        >
          VIEW ENTIRE ARMORY
        </motion.button>
      </div>
    </section>
  );
}
