import { motion } from 'motion/react';
import { ShoppingCart, User, LogIn, Menu, X, Github, Mail } from 'lucide-react';
import { useState, useEffect } from 'react';
import { auth } from '../lib/firebase';
import { 
  OAuthProvider, 
  GoogleAuthProvider, 
  GithubAuthProvider, 
  signInWithPopup, 
  onAuthStateChanged, 
  signOut, 
  User as FirebaseUser 
} from 'firebase/auth';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showLoginOptions, setShowLoginOptions] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  const login = async (providerName: 'discord' | 'google' | 'github') => {
    let provider;
    if (providerName === 'discord') {
      provider = new OAuthProvider('discord.com');
    } else if (providerName === 'google') {
      provider = new GoogleAuthProvider();
    } else {
      provider = new GithubAuthProvider();
    }

    try {
      await signInWithPopup(auth, provider);
      setShowLoginOptions(false);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const logout = () => signOut(auth);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-dark-bg/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center space-x-2">
            <motion.div 
              initial={{ scale: 0.8, rotate: -10 }}
              animate={{ scale: 1, rotate: 0 }}
              className="w-10 h-10 bg-neon-cyan flex items-center justify-center rounded-lg shadow-neon-cyan"
            >
              <span className="font-bold text-black text-xl">N</span>
            </motion.div>
            <span className="text-2xl font-black tracking-tighter neon-text-cyan hidden sm:block">NEON NEXUS</span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-white/70 hover:text-neon-cyan transition-colors font-medium">Marketplace</a>
            <a href="#" className="text-white/70 hover:text-neon-cyan transition-colors font-medium">Creators</a>
            <a href="#" className="text-white/70 hover:text-neon-cyan transition-colors font-medium">Community</a>
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 text-white/70 hover:text-neon-cyan transition-colors">
              <ShoppingCart size={24} />
            </button>
            {user ? (
              <div className="flex items-center space-x-4">
                <img src={user.photoURL || ''} alt="avatar" className="w-8 h-8 rounded-full border border-neon-magenta shadow-neon-magenta" />
                <button onClick={logout} className="text-sm font-medium text-white/50 hover:text-white">Logout</button>
              </div>
            ) : (
              <div className="relative">
                <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowLoginOptions(!showLoginOptions)}
                  className="flex items-center space-x-2 bg-transparent border border-neon-magenta text-neon-magenta px-6 py-2 rounded-full font-bold shadow-neon-magenta hover:bg-neon-magenta hover:text-white transition-all"
                >
                  <LogIn size={18} />
                  <span>Sign In</span>
                </motion.button>

                {showLoginOptions && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute right-0 mt-4 w-48 bg-dark-card border border-white/10 rounded-2xl p-2 shadow-2xl z-[100]"
                  >
                    <button 
                      onClick={() => login('discord')}
                      className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors text-white font-medium"
                    >
                      <MessageSquare size={18} className="text-[#5865F2]" />
                      <span>Discord</span>
                    </button>
                    <button 
                      onClick={() => login('google')}
                      className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors text-white font-medium"
                    >
                      <Mail size={18} className="text-[#EA4335]" />
                      <span>Google</span>
                    </button>
                    <button 
                      onClick={() => login('github')}
                      className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors text-white font-medium"
                    >
                      <Github size={18} className="text-white" />
                      <span>GitHub</span>
                    </button>
                  </motion.div>
                )}
              </div>
            )}
            <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-dark-bg border-b border-white/10 px-4 py-6 space-y-4"
        >
          <a href="#" className="block text-xl font-bold text-white hover:neon-text-cyan">Marketplace</a>
          <a href="#" className="block text-xl font-bold text-white hover:neon-text-cyan">Creators</a>
          <a href="#" className="block text-xl font-bold text-white hover:neon-text-cyan">Community</a>
        </motion.div>
      )}
    </nav>
  );
}
import { MessageSquare } from 'lucide-react';
