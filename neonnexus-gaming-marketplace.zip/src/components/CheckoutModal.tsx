import { motion, AnimatePresence } from 'motion/react';
import { X, CreditCard, ShieldCheck, Download, Zap } from 'lucide-react';
import { Product } from '../types';

interface Props {
  product: Product | null;
  onClose: () => void;
}

export default function CheckoutModal({ product, onClose }: Props) {
  if (!product) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/90 backdrop-blur-sm"
        />
        
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="relative w-full max-w-lg bg-dark-card border border-white/10 rounded-[32px] overflow-hidden shadow-2xl"
        >
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 text-white/50 hover:text-white transition-colors z-10"
          >
            <X size={24} />
          </button>

          <div className="p-8">
            <div className="flex items-center space-x-2 text-neon-cyan mb-6">
              <Zap size={20} fill="currentColor" />
              <span className="text-xs font-black uppercase tracking-widest">Secure Checkout</span>
            </div>

            <div className="flex items-start space-x-6 mb-10">
              <div className="w-24 h-24 rounded-2xl overflow-hidden flex-shrink-0 border border-white/10">
                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
              </div>
              <div>
                <h3 className="text-2xl font-black italic tracking-tight mb-1">{product.name}</h3>
                <p className="text-white/40 text-sm mb-2">{product.category}</p>
                <div className="text-xl font-black text-neon-magenta">${product.price}</div>
              </div>
            </div>

            <div className="space-y-4 mb-10">
              <div className="flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-2xl">
                <div className="flex items-center space-x-3">
                  <CreditCard className="text-white/40" />
                  <span className="font-bold text-white/70">Payment Method</span>
                </div>
                <span className="text-xs font-black text-neon-cyan uppercase tracking-widest">NEXUS PAY</span>
              </div>
              <div className="p-4 bg-neon-lime/5 border border-neon-lime/20 rounded-2xl flex items-center space-x-3 text-neon-lime">
                <ShieldCheck size={20} />
                <span className="text-sm font-bold">Instant Digital Delivery after payment</span>
              </div>
            </div>

            <button
              onClick={() => {
                alert('Order simulated! In a real app, this would trigger a payment gateway.');
                onClose();
              }}
              className="w-full py-5 bg-neon-cyan text-black font-black italic rounded-2xl shadow-neon-cyan hover:brightness-110 transition-all flex items-center justify-center space-x-3"
            >
              <Download size={20} />
              <span>PURCHASE & DOWNLOAD</span>
            </button>

            <p className="mt-6 text-center text-[10px] text-white/20 uppercase tracking-widest font-bold">
              Final price includes all taxes and digital delivery fees.
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
