export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl: string;
  downloadUrl?: string;
  sellerId: string;
  rating: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  avatarUrl: string;
  purchasedItems: string[];
}

export interface Testimonial {
  id: string;
  userName: string;
  userAvatar: string;
  text: string;
  rating: number;
  game: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}
