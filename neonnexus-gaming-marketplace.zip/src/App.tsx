/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';
import PricingTables from './components/PricingTables';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';
import { motion, useScroll, useSpring } from 'motion/react';

export default function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="min-h-screen bg-dark-bg selection:bg-neon-cyan selection:text-black">
      {/* Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-neon-cyan origin-left z-[100]"
        style={{ scaleX }}
      />
      
      <Navbar />
      
      <main>
        <Hero />
        
        {/* Marketplace Section with Anchor */}
        <div id="armory" className="relative group">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-px bg-gradient-to-r from-transparent via-neon-cyan/20 to-transparent" />
          <ProductGrid />
        </div>

        <PricingTables />
        
        <Testimonials />

        {/* CTA Section */}
        <section className="py-32 px-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-5xl mx-auto relative rounded-[40px] overflow-hidden bg-gradient-to-br from-neon-cyan/10 via-transparent to-neon-magenta/10 border border-white/10 p-12 md:p-24 text-center"
          >
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(0,243,255,0.05),transparent)] pointer-events-none" />
            
            <h2 className="text-4xl md:text-7xl font-black italic tracking-tighter mb-8 uppercase leading-[0.9]">
              READY TO <span className="neon-text-cyan">ASCEND?</span>
            </h2>
            <p className="text-xl text-white/50 mb-12 max-w-2xl mx-auto">
              Join the future of gaming trade. Access elite assets, secure transactions, and a community of high-performance players.
            </p>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-black px-12 py-5 rounded-full font-black italic shadow-[0_0_40px_rgba(255,255,255,0.2)] hover:shadow-[0_0_60px_rgba(0,243,255,0.4)] transition-all"
            >
              CREATE FREE ACCOUNT
            </motion.button>
          </motion.div>
        </section>
      </main>

      <Footer />

      {/* Global Background Particles/Effects */}
      <div className="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-[10%] left-[15%] w-1 h-1 bg-white rounded-full animate-ping opacity-20" />
        <div className="absolute top-[40%] right-[25%] w-1 h-1 bg-neon-cyan rounded-full animate-ping delay-700 opacity-20" />
        <div className="absolute bottom-[20%] left-[45%] w-1 h-1 bg-neon-magenta rounded-full animate-ping delay-1000 opacity-20" />
      </div>
    </div>
  );
}
